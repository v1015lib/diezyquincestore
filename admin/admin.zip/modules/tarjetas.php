<div class="module-header">
    <h2 class="modules_head">Gestión de Tarjetas Recargables</h2>
        <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="tarjetas/gestion">Gestión y Asignación</button>

        <button class="action-btn" data-action="tarjetas/recargar">Recargar Saldo</button>
        <button class="action-btn" data-action="tarjetas/reporte_clientes">Reporte de Clientes</button>
    </div>
</div>

<div id="action-content" class="module-content">
</div>