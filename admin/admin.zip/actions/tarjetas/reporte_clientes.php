<div class="list-header">
    <h3>Reporte de Clientes con Tarjetas Asignadas</h3>
</div>

<div class="product-list-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>Usuario</th>
                <th>Nombre Completo</th>
                <th>Número de Tarjeta</th>
                <th>Saldo Actual</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody id="card-report-tbody">
            </tbody>
    </table>
</div>