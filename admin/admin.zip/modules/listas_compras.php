<div class="module-header">
    <h2 class="modules_head">Listas de Compras</h2>
    <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="listas_compras/gestion">Gestionar Listas</button>
        <button class="action-btn" data-action="listas_compras/crear_lista">Crear Nueva Lista</button>
    </div>
</div>

<div id="action-content" class="module-content">
</div>