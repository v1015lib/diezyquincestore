<?php 
session_start();

require_once __DIR__ . '/../../api/download_barcodes.php';

 ?>