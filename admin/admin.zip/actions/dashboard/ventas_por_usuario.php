<div class="list-header">
    <h3>Reporte de Ventas por Usuario (Últimos 7 días)</h3>
</div>

<div class="product-list-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>Nombre de Usuario</th>
                <th>Total Vendido</th>
                <th>Número de Ventas</th>
            </tr>
        </thead>
        <tbody id="user-sales-tbody">
            </tbody>
    </table>
</div>
