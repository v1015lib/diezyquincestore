<?php
session_start();
//Router para llamar a la api principal y no exponerla en public_html

require_once __DIR__ . '/../../api/index.php';

?>