<div class="module-header">
    <h2 class="modules_head">Gestión de Tiendas</h2>
        <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="tiendas/gestion">Gestionar Tiendas</button>
    </div>
</div>
<div id="action-content" class="module-content"></div>