<div class="module-header">
    <h2 class="modules_head">Dashboard y Reportes</h2>

    <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="dashboard/log_actividad">Log de Actividad</button>
        <button class="action-btn " data-action="dashboard/ventas_por_usuario">Ventas por Usuario</button>
    </div>
    
</div>

<div id="action-content" class="module-content">
    </div>