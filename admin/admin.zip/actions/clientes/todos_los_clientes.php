<?php
session_start();


    
?>


<div class="list-header">
    <div class="search-container">
        <input type="text" id="customer-search-input" placeholder="Buscar por nombre, usuario, email o teléfono...">
    </div>
</div>

<div class="product-list-container" id="client-list-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>Usuario</th>
                <th>Nombre Completo</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Tipo</th>
                <th>N° Tarjeta</th>
                <th>Estado Tarjeta</th>
                <th>Editar</th>
                <th>Eliminar</th> </tr>
        </thead>
        <tbody id="customer-table-body">
            </tbody>
    </table>
</div>