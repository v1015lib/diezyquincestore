<?php
// EN: admin/modules/marcas.php
?>
<div class="module-header">
    <h2 class="modules_head">Gestión de Marcas</h2>
    <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="marcas/gestion">Gestionar Marcas</button>
    </div>
</div>

<div id="action-content" class="module-content">
</div>