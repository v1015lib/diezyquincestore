<div class="module-header">
    <h2 class="modules_head">Utilidades del Sistema</h2>
    <button class="ribbon_toggle">Acciones</button>
    <div class="action-ribbon">
        <button class="action-btn active" data-action="utilidades/generador_codigos">Generador de Códigos</button>
        <button class="action-btn" data-action="utilidades/procesador_imagenes">Optimizar Imágenes</button>
        <button class="action-btn" data-action="utilidades/bucket_manager">Administrador de Bucket</button> 
        <button class="action-btn " data-action="utilidades/copia_seguridad">Copia de Seguridad</button>
   </div>
</div>
<div id="action-content" class="module-content"></div>