<div class="module-header">
    <h2 class="modules_head">Gestión de Clientes</h2>
        <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="clientes/todos_los_clientes">Lista de Clientes</button>
        <button class="action-btn" data-action="clientes/nuevo_cliente">Nuevo Cliente</button>
        <button class="action-btn" data-action="clientes/modificar_cliente">Modificar Cliente</button>
    </div>
</div>

<div id="action-content" class="module-content">
    </div>