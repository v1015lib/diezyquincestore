<div class="module-header">
    <h2 class="modules_head">Gestión de Usuarios</h2>
        <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="usuarios/gestion">Gestionar Empleados</button>
        <button class="action-btn" data-action="usuarios/permisos">Gestionar Permisos de Roles</button>
    </div>
</div>

<div id="action-content" class="module-content">
</div>