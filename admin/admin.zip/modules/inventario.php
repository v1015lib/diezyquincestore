<div class="module-header">
    <h2 class="modules_head">Gestión de Inventario</h2>
        <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="inventario/agregar_stock">Agregar Stock</button>
        <button class="action-btn" data-action="inventario/ajuste_inventario">Ajuste de Inventario</button>
        <button class="action-btn" data-action="inventario/historial_movimientos">Historial de Movimientos</button>
    </div>
</div>

<div id="action-content" class="module-content">
    </div>