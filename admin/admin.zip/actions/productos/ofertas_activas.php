

<div class="list-header">
    <h3>Vista General de Ofertas Activas</h3>
</div>

<div class="product-list-container" id="active-offers-list-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre del Producto</th>
                <th>P. Venta</th>
                <th>P. Oferta</th>
                <th>Caducidad</th>
            </tr>
        </thead>
        <tbody id="active-offers-table-body">
            </tbody>
    </table>
</div>
