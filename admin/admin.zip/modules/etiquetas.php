<?php
// EN: admin/modules/etiquetas.php
?>
<div class="module-header">
    <h2 class="modules_head">Gestión de Etiquetas</h2>
    <button class="ribbon_toggle">Acciones</button>

    <div class="action-ribbon">
        <button class="action-btn active" data-action="etiquetas/gestion">Gestionar Etiquetas</button>
    </div>
</div>

<div id="action-content" class="module-content">
</div>